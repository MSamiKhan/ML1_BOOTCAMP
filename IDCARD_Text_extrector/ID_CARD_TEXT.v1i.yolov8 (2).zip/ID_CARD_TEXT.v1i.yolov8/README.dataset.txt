# ID_CARD_TEXT > 2024-08-29 4:21pm
https://universe.roboflow.com/datset-5rhux/id_card_text

Provided by a Roboflow user
License: CC BY 4.0

